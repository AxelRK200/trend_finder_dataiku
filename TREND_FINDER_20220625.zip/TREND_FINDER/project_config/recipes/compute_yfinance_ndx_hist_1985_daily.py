# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import yfinance as yf

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
ndx = yf.Ticker("^NDX")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_historical_data = ndx.history(interval="1d", period="max")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_historical_data.drop(columns=["Dividends","Stock Splits"], inplace=True)
df_historical_data.reset_index(inplace=True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Test si aucune ligne manquante
test_list = [champ == 0 for champ in df_historical_data.isnull().sum()]

# Si toutes les colonnes sont True, résultat = True
res1 = all(i for i in test_list)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Test si toutes les colonnes > 0
test_list_zero = [champ > 0 for champ in df_historical_data.describe().min()]
res2 = all(z for z in test_list_zero)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
yfinance_ndx_hist_1985_daily = dataiku.Dataset("yfinance_ndx_hist_1985_daily")

if res1 & res2 :
    yfinance_ndx_hist_1985_daily.write_with_schema(df_historical_data.round(2))
    print("Import réussi et tests validés")
    print("Nombre de lignes : ",df_historical_data.shape[0])
else :
    print("Au moins une ligne est vide ou une valeur est incohérente.\nPas d'écriture")