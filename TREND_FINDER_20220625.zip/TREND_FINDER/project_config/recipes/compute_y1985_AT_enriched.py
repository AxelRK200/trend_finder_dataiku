# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Read recipe inputs
y1985_AT = dataiku.Dataset("y1985_AT")
df_source = y1985_AT.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Sélection uniquement des colonnes Trends sur lesquelles on va calculer les Windows
trends = [c for c in range(2,19,3)]
cols = df_source.columns.to_list()
trend_cols = [cols[c] for c in trends]
print(trend_cols)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
for e in trend_cols :
    df_source[e+"_w5"] = df_source[e].rolling(5).mean()
    df_source[e+"_w10"] = df_source[e].rolling(10).mean()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
y1985_AT_enriched = dataiku.Dataset("y1985_AT_enriched")
y1985_AT_enriched.write_with_schema(df_source)