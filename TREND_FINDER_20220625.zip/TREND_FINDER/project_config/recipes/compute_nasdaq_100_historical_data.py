# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import datetime
import investpy

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Obtention de la date du jour, format texte, pour paramètre date_max investpy
current_time = datetime.datetime.now()

date_jour = str(current_time.day) + "/" + str(current_time.month) + "/" + str(current_time.year)
print("Date du jour : ",date_jour)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# Le 15 Juin 2006 est identifié comme la première date intégrant les données de volume

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_historical_data = investpy.indices.get_index_historical_data(
    index="Nasdaq 100",
    country="united states",
    from_date="15/06/2006",
    to_date=date_jour
)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Par défaut la colonne date est un index.
# Passage de celle-ci en colonne
df_historical_data.reset_index(inplace=True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
df_historical_data.drop(columns="Currency", inplace=True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Test si aucune ligne manquante
test_list = [champ == 0 for champ in df_historical_data.isnull().sum()]
# Si toutes les colonnes sont True, résultat = True
res1 = all(i for i in test_list)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Test si toutes les colonnes > 0
test_list_zero = [champ > 0 for champ in df_historical_data.describe().min()]
res2 = all(z for z in test_list_zero)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
nasdaq_100_historical_data = dataiku.Dataset("investpy_ndx_hist_2006_daily")

if res1 & res2 :
    nasdaq_100_historical_data.write_with_schema(df_historical_data)
    print("Import réussi et tests validés")
    print("Nombre de lignes : ",df_historical_data.shape[0])
else :
    print("Au moins une ligne est vide ou une valeur est incohérente.\nPas d'écriture")